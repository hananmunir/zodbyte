export const SOURCE_SRC = [
    "https://nortalweb.wpenginepowered.com/wp-content/uploads/2022/05/img-future-portrait.jpg",
    "https://media.istockphoto.com/photos/office-skysraper-in-the-sun-picture-id523875332?b=1&k=20&m=523875332&s=612x612&w=0&h=hQrhhA0zbzz1l3ZVUXfwz7ou5Xig3kEw0rtGtj3ADO0=",
    "https://media.istockphoto.com/photos/new-york-city-manhattan-downtown-skyline-picture-id599100186?b=1&k=20&m=599100186&s=612x612&w=0&h=wAhzt_t-6JTlML_FnnJh1RDNZdtUR8JQf8ykSXkr-bU=",
    "https://nortalweb.wpenginepowered.com/wp-content/uploads/2022/05/img-future-portrait.jpg",
];
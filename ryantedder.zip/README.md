## FIGMA TO @REACT JS

## How to run project
## cmd -> `yarn start`

# Figma Link
https://www.figma.com/file/ONCmwBsCBZbzaXYfIhjz8g/ZODBYTE-2K22?node-id=0%3A1

# Here is also the font being used on some places, others its Roboto.
https://github.com/mcansh/yeezy-logo-font

# Nortal
https://nortal.com/

# Form send to
zodbyte@gmail.com

# Requirements
1- humburger Icon
2- lang converter in the menu
3- lang drop should have width auto
4- image should be zoom from anywhere over hover
5- form should match calendy
6- add email on which info will be sent
7- calendy title should be center
8- from the header the items should nav to related sections
9- header animation (disappear on scroll down when it passes the hero section, appear on scroll up at any point)
